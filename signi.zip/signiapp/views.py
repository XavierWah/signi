from django.http import HttpResponseRedirect, Http404
from django.shortcuts import render, get_object_or_404
from . import models, get_ip

import base64
import time


def index(request):
    context = {
        'header': {
            'motd': [
                '页面加载时间: {}'.format(time.asctime()),
                '您正在访问 Alpha 测试阶段的 Signi.'
            ]
        },
        'signi_records': models.SigniRecord.objects.all()
    }
    return render(request, 'signiapp/index.html', context)


def submit(request, record_id):
    if request.method == "POST":
        try:
            record = get_object_or_404(models.SigniRecord, pk=record_id)
        except (KeyError, models.SigniRecord.DoesNotExist) as err:
            return Http404(err)
        else:
            data = {
                'name': request.POST['name'],
                'signature': request.POST['signature'],
                'time': time.time(),
                'ip': get_ip(request)
            }
            record.records.append(str(base64.b64encode(str(data).encode('utf-8')), 'utf-8'))
            record.save()
            return HttpResponseRedirect('success?name={}&time={}'.format(data['name'], data['time']))
    record = get_object_or_404(models.SigniRecord, pk=record_id)
    context = {
        'record': record
    }
    return render(request, 'signiapp/detail.html', context)


def success(request, record_id):
    record = get_object_or_404(models.SigniRecord, pk=record_id)
    context = {
        'record': record,
        'data': {
            'name': request.GET['name'],
            'time': time.asctime()
        }
    }
    return render(request, 'signiapp/success.html', context)
