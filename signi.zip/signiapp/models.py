from django.db.models import Model, IntegerField, BooleanField, CharField
from django_mysql.models import ListCharField


class SigniRecord(Model):
    id = IntegerField(primary_key=True)
    open = BooleanField(default=False)
    title = CharField(max_length=256)
    tags = ListCharField(base_field=CharField(max_length=256), size=32, max_length=(256 + 1) * 32, blank=True)
    records = ListCharField(base_field=CharField(max_length=512), size=2048, max_length=(512 + 1) * 2048, blank=True)

    def __str__(self):
        return self.title
